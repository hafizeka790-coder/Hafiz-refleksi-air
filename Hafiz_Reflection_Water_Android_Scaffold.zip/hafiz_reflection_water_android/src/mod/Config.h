#pragma once

#include <string>
#include <string_view>

#include <pl/Config.hpp>

namespace hafiz_reflection_water {

struct ModConfig {
    int version = 1;
    bool enabled = true;
    std::string message = "Hafiz Reflection Water native scaffold loaded";
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace hafiz_reflection_water

template <> struct pl::config::Schema<hafiz_reflection_water::ModConfig> {
    static constexpr std::string_view title = "Hafiz Reflection Water Config";
    static constexpr std::string_view description = {};

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version")
            return {.title = "Version", .readOnly = true};
        if (name == "enabled")
            return {.title = "Enabled", .description = "Turns hafiz_reflection_water behavior on or off."};
        if (name == "message")
            return {.title = "Message", .description = "Message written when the mod is enabled."};
        return {};
    }
};
