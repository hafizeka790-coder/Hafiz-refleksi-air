#include "mod/MyMod.h"

#include <filesystem>

#include <pl/Mod.hpp>

namespace hafiz_reflection_water {

HafizReflectionWaterMod &HafizReflectionWaterMod::instance() {
    static HafizReflectionWaterMod instance;
    return instance;
}

HafizReflectionWaterMod::HafizReflectionWaterMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool HafizReflectionWaterMod::load() {
    auto &self = getSelf();
    self.getLogger().debug("Loading...");

    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create data directory {}: {}", self.getDataDir().string(),
                               ec.message());
        return false;
    }

    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create config directory {}: {}",
                               self.getConfigDir().string(), ec.message());
        return false;
    }

    mConfigFile.emplace();
    if (!mConfigFile->load()) {
        self.getLogger().warn("Failed to load typed config");
        return false;
    }
    mConfig = mConfigFile->value();

    self.getLogger().info("Loaded {} from {}", self.getName(), self.getModDir().string());
    return true;
}

bool HafizReflectionWaterMod::enable() {
    auto &self = getSelf();
    self.getLogger().debug("Enabling...");
    if (!mConfig.enabled) {
        self.getLogger().info("Hafiz Reflection Water is disabled by config");
        return true;
    }

    self.getLogger().info("Config message: {}", mConfig.message);
    return true;
}

bool HafizReflectionWaterMod::disable() {
    getSelf().getLogger().debug("Disabling...");
    // Undo enable-time state here.
    return true;
}

bool HafizReflectionWaterMod::unload() {
    getSelf().getLogger().debug("Unloading...");
    // Release load-time resources here.
    mConfigFile.reset();
    return true;
}

} // namespace hafiz_reflection_water
