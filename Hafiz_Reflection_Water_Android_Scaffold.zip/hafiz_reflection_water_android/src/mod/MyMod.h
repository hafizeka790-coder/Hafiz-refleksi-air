#pragma once

#include <optional>

#include "mod/Config.h"

#include <pl/Mod.hpp>

namespace hafiz_reflection_water {

class HafizReflectionWaterMod {
  public:
    static HafizReflectionWaterMod &instance();

    HafizReflectionWaterMod();

    [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

  private:
    ll::mod::NativeMod &mSelf;
    ModConfig mConfig;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;
};

} // namespace hafiz_reflection_water
