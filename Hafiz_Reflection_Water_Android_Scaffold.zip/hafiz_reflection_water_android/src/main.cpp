#include "mod/MyMod.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(hafiz_reflection_water::HafizReflectionWaterMod, hafiz_reflection_water::HafizReflectionWaterMod::instance());
