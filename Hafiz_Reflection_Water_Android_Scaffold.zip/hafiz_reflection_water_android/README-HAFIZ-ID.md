# Hafiz Reflection Water — native mod scaffold (ARM64)

This is an Android native-mod scaffold for LeviLauncher, customized from the supplied LeviLauncher Android Mod Template. It is NOT a working SSR/reflection implementation yet. It only builds the native lifecycle scaffold and verifies that the mod can be loaded.

## Target
- LeviLauncher `preload-native` package
- Android ABI: `arm64-v8a`
- Minecraft version declaration: `26.60` (must be verified against the installed game's actual version/build)
- Android NDK 28.2.13676358, CMake 3.22+, Ninja, PowerShell 7+

## Build from an Android phone using GitHub Actions
1. Extract this ZIP on your phone.
2. Create a new GitHub repository named `hafiz-reflection-water`.
3. Upload the extracted project files/folders to the repository root (including hidden `.github` folder).
4. Open the repository → Actions → allow GitHub Actions if prompted.
5. Run the `Build` workflow using **Run workflow**, or push a commit to `main`.
6. When it completes, open the workflow run → Artifacts → download `hafiz-reflection-water-arm64`.
7. The artifact should contain a `.levipack` package. Import it into LeviLauncher for a load test.

## Important limitation
The supplied shader-codebase ZIP contains reconstructed GLSL/BGFX shader sources, including DeferredWater and SSR passes. Those shader sources are not automatically injectable into Minecraft by a native mod. A real reflection implementation still requires a version-matched rendering integration: identify the actual 26.60 RenderDragon render-pass/material interfaces and resources, then safely register/replace the relevant shader/material and provide the required color/depth/normal buffers. The Preloader hook API alone does not identify those functions or provide a shader injection API. Do not guess function addresses or byte signatures.

This scaffold intentionally does not install speculative hooks or patch game memory. It is a safe first build/load test, not a finished water-reflection mod.
